<h1>Payment Success</h1>
<p>Thank you! Your payment for Order ID {{ $orderId }} has been successfully processed.</p>
