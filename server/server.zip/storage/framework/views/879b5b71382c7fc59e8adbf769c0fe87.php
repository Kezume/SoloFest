<!DOCTYPE html>
<html>
<head>
    <title>e-Ticket</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .content {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            font-size: 12px;
            color: #555;
        }
    </style>
</head>
<body>
    <?php for($i = 0; $i < $purchase->quantity; $i++): ?>
        <div class="header">
            <h1><?php echo e($event->name); ?></h1>
            <p><strong>Date:</strong> <?php echo e($event->date); ?></p>
            <p><strong>Location:</strong> <?php echo e($event->location); ?></p>
        </div>
        <div class="content">
            <p><strong>Order ID:</strong> ORDER-<?php echo e($purchase->id); ?></p>
            <p><strong>Ticket Type:</strong> <?php echo e($ticket->type); ?></p>
            <p><strong>Ticket Number:</strong> <?php echo e($i + 1); ?> of <?php echo e($purchase->quantity); ?></p>
            <p><strong>Total Price:</strong> Rp <?php echo e(number_format($purchase->total_price, 0, ',', '.')); ?></p>
            
        </div>
        <div class="footer">
            <p>This e-ticket is valid only for the specified event. Please present this ticket at the event venue as proof of purchase.</p>
        </div>
        <?php if($i < $purchase->quantity - 1): ?>
            <div style="page-break-after: always;"></div>
        <?php endif; ?>
    <?php endfor; ?>
</body>
</html>
<?php /**PATH D:\Programming\Laravel\projects\SoloFest\server\resources\views/tickets/pdf.blade.php ENDPATH**/ ?>