<h1>Hi, <?php echo e($user->name); ?>!</h1>

<p>Thank you for purchasing tickets for <strong><?php echo e($event->name); ?></strong>.</p>

<p><strong>Event Details:</strong></p>
<ul>
    <li>Event: <?php echo e($event->name); ?></li>
    <li>Date: <?php echo e($event->start_date); ?></li>
    <li>Location: <?php echo e($event->location); ?></li>
    <li>Ticket Type: <?php echo e($ticket->type); ?></li>
    <li>Quantity: <?php echo e($purchase->quantity); ?></li>
</ul>

<p>Please keep this email as proof of your purchase.</p>

<p>Thank you,</p>
<p>The Event Team</p>
<?php /**PATH D:\Programming\Laravel\projects\SoloFest\server\resources\views/emails/ticket.blade.php ENDPATH**/ ?>